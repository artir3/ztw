https\://docs.google.com/document/d/1RhIkHE7jH7lrmm_sdXjyt0XqtOcRJvX2Ds9WlcrdDpc/edit\?ts\=5a97033b

